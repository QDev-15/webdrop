<?php
declare(strict_types=1);
ini_set('display_errors', '0');
error_reporting(E_ALL);

require_once __DIR__ . '/src/bootstrap.php';

$method = $_SERVER['REQUEST_METHOD'];
$uri    = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// Strip /api prefix if accessed via subdirectory
$uri = preg_replace('#^/api#', '', $uri) ?: '/';

try {
    $router->dispatch($method, $uri);
} catch (Throwable $e) {
    Response::json([
        'error'   => 'Lỗi hệ thống',
        'message' => APP_ENV === 'development' ? $e->getMessage() : 'Vui lòng thử lại sau',
    ], 500);
}
